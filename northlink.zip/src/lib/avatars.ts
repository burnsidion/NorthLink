export const AVATARS = [
  "🎄", "🎁", "🧦", "🛷", "☃️", "🦌", "🧝", "⭐️",
];
