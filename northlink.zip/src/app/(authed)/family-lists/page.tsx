"use client";
//Deps
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { supabase } from "@/lib/supabase";

//components
import ListCard, { ListWithProgress } from "@/components/lists/list-card";
import Snowfall from "@/components/ui/snowfall";
import { StarsBackground } from "@/components/ui/stars-background";
import { HeroHighlight, Highlight } from "@/components/ui/hero-highlight";

//Animation
import { motion } from "motion/react";

export default function FamilyListsPage() {
	const router = useRouter();

	const [lists, setLists] = useState<ListWithProgress[]>([]);
	const [loading, setLoading] = useState(true);
	const [error, setError] = useState<string | null>(null);

	useEffect(() => {
		let alive = true;

		(async () => {
			// 1) Check session like on landing page
			const {
				data: { session },
				error: sessionError,
			} = await supabase.auth.getSession();

			if (sessionError) {
				console.error("Error getting session:", sessionError);
			}

			if (!session) {
				router.replace("/login");
				return;
			}

			const userId = session.user.id;

			// 2) Fetch all accessible lists from the view
			const { data, error } = await supabase
				.from("v_user_accessible_lists")
				.select("*")
				.order("created_at", { ascending: false });

			if (!alive) return;

			if (error) {
				console.error("Error fetching accessible lists:", error);
				setError(error.message);
				setLoading(false);
				return;
			}

			// 3) Filter to only lists owned by OTHER users
			const filtered = (data ?? []).filter(
				(l) => l.owner_user_id !== userId
			) as ListWithProgress[];

			setLists(filtered);
			setLoading(false);
		})();

		return () => {
			alive = false;
		};
	}, [router]);

	if (loading) {
		return (
			<main className="max-w-6xl mx-auto px-4 py-10 text-white">
				<StarsBackground starColor="var(--stars-dim)" />
				<h1 className="text-3xl sm:text-4xl font-bold mb-4">Shared Lists</h1>
				<p className="text-white/70">Loading shared lists…</p>
			</main>
		);
	}

	if (error) {
		return (
			<main className="max-w-6xl mx-auto px-4 py-10 text-white">
				<StarsBackground starColor="var(--stars-dim)" />
				<h1 className="text-3xl sm:text-4xl font-bold mb-4">Shared Lists</h1>
				<p>Something went wrong loading your shared lists.</p>
			</main>
		);
	}

	return (
		<main className="max-w-6xl mx-auto px-4 py-10 text-white">
			<StarsBackground starColor="var(--stars-dim)" />
			<Snowfall />
			<HeroHighlight className="bg-none mb-12">
				<motion.h1
					initial={{
						opacity: 0,
						y: 20,
					}}
					animate={{
						opacity: 1,
						y: [20, -5, 0],
					}}
					transition={{
						duration: 0.5,
						ease: [0.4, 0.0, 0.2, 1],
					}}
					className="text-2xl px-4 md:text-4xl lg:text-5xl font-bold text-neutral-700 dark:text-white max-w-4xl leading-relaxed lg:leading-snug text-center mx-auto "
				>
					<Highlight className="text-black dark:text-white">Browse</Highlight>{" "}
					wish lists from your
					<br />
					<Highlight className="text-black dark:text-white">
						friends and family
					</Highlight>{" "}
					{/* Family Lists. */}
					<br />{" "}
					<Highlight className="text-black dark:text-white">Click</Highlight>
					on a list to view items and mark gifts as{" "}
					<Highlight className="text-black dark:text-white">
						purchased
					</Highlight>
				</motion.h1>
			</HeroHighlight>

			{lists.length === 0 ? (
				<p className="text-white/70 text-center">
					You don&apos;t have any shared lists yet. Once friends or family share
					lists with you, they&apos;ll appear here.
				</p>
			) : (
				<section className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
					{lists.map((list) => (
						<ListCard key={list.id} list={list} hideManageButton showOwner />
					))}
				</section>
			)}
		</main>
	);
}
